/** Automatically generated file. DO NOT MODIFY */
package edu.ncsu.csc450.intelligentalarm;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}